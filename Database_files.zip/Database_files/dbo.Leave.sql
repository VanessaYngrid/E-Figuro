﻿CREATE TABLE [dbo].[Leave] (
    [leave_id]   VARCHAR (255) NOT NULL,
    [emp_id]     VARCHAR (50)  NULL,
    [admin_id]   VARCHAR (50)  NULL,
    [reason_id]  INT           NULL,
    [start_date] DATE          NULL,
    [end_date]   DATE          NULL,
    [no_days]    INT           NULL,
    PRIMARY KEY CLUSTERED ([leave_id] ASC),
    FOREIGN KEY ([emp_id]) REFERENCES [dbo].[Employee] ([emp_id]),
    FOREIGN KEY ([admin_id]) REFERENCES [dbo].[Administrator] ([admin_id]),
    FOREIGN KEY ([reason_id]) REFERENCES [dbo].[MaxLeave] ([reason_id])
);

