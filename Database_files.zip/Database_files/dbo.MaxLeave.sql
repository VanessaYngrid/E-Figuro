﻿CREATE TABLE [dbo].[MaxLeave] (
    [reason_id]    INT           NOT NULL,
    [leave_reason] VARCHAR (255) NULL,
    [max_days]     INT           NOT NULL,
    PRIMARY KEY CLUSTERED ([reason_id] ASC)
);

