﻿CREATE TABLE [dbo].[Employee] (
    [emp_id]         VARCHAR (50) NOT NULL,
    [emp_name]       VARCHAR (50) NOT NULL,
    [emp_email]      VARCHAR (50) NOT NULL,
    [emp_password]   VARCHAR (50) NOT NULL,
    [emp_position]   VARCHAR (50) NOT NULL,
    [emp_department] VARCHAR (50) NOT NULL,
    [emp_hire_date]  DATE         NOT NULL,
    [emp_salary]     FLOAT (53)   NOT NULL,
    [emp_birth_date] DATE         NOT NULL,
    [emp_address]    VARCHAR (50) NOT NULL,
    PRIMARY KEY CLUSTERED ([emp_id] ASC),
    CONSTRAINT [EM_Employee] UNIQUE NONCLUSTERED ([emp_email] ASC)
);

