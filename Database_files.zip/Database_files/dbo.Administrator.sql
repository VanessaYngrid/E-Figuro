﻿CREATE TABLE [dbo].[Administrator] (
    [admin_id]         VARCHAR (50) NOT NULL,
    [admin_name]       VARCHAR (50) NOT NULL,
    [admin_email]      VARCHAR (50) NOT NULL,
    [admin_password]   VARCHAR (50) NOT NULL,
    [admin_position]   VARCHAR (50) NOT NULL,
    [admin_department] VARCHAR (50) NOT NULL,
    [admin_hire_date]  DATE         NOT NULL,
    [admin_salary]     FLOAT (53)   NOT NULL,
    [admin_birth_date] DATE         NOT NULL,
    [admin_address]    VARCHAR (50) NOT NULL,
    PRIMARY KEY CLUSTERED ([admin_id] ASC),
    CONSTRAINT [EM_Administrator] UNIQUE NONCLUSTERED ([admin_email] ASC)
);

