﻿CREATE TABLE [dbo].[TimeSheet] (
    [time_id]    VARCHAR (50)    NOT NULL,
    [emp_id]     VARCHAR (50)    NULL,
    [admin_id]   VARCHAR (50)    NULL,
    [clock_date] DATE            NOT NULL,
    [punchIn]    TIME (7)        NULL,
    [mealOut]    TIME (7)        NULL,
    [mealIn]     TIME (7)        NULL,
    [punchOut]   TIME (7)        NULL,
    [totalHours] DECIMAL (18, 2) NULL,
    PRIMARY KEY CLUSTERED ([time_id] ASC),
    FOREIGN KEY ([emp_id]) REFERENCES [dbo].[Employee] ([emp_id]),
    FOREIGN KEY ([admin_id]) REFERENCES [dbo].[Administrator] ([admin_id])
);

