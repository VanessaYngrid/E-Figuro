using E_Figuro_WPF.Models;

namespace E_Figuro_NUnitTest
{
    public class Tests
    {
        // testing for PayrollClass.cs

        PayrollClass payroll { get; set; } = null;

        [SetUp]
        public void Setup()
        {
            payroll = new PayrollClass(50.0, 2080.0);
        }

        [Test]
        public void calculateEarningsTest()
        {
            double expected_earnings = 104000.0, actual_earnings;

            actual_earnings = payroll.calculateEarnings();

            Assert.AreEqual(expected_earnings, actual_earnings);

            Assert.That(actual_earnings, Is.TypeOf<double>());

            Assert.Pass();
        }

        [Test]
        public void calculateTaxesTest()
        {
            double expected_taxedSalary = 26000.0, actual_taxedSalary;

            actual_taxedSalary = payroll.calculateTaxes();

            Assert.AreEqual(expected_taxedSalary, actual_taxedSalary);

            Assert.That(actual_taxedSalary, Is.TypeOf<double>());

            Assert.Pass();
        }

        [Test]
        public void calculateNetPayTest()
        {
            double expected_netPay = 78000.0, actual_netPay;

            actual_netPay = payroll.calculateNetPay();

            Assert.AreEqual(expected_netPay, actual_netPay);

            Assert.That(actual_netPay, Is.TypeOf<double>());

            Assert.Pass();
        }
    }
}