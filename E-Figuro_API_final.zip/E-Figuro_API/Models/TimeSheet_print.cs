﻿namespace E_Figuro_API.Models
{
    public class TimeSheet_print
    {
        // class based on TimeSheet to selectively show only the information we want to be seen in the datatable
        public DateTime clock_date { get; set; }
        public TimeSpan? punchIn { get; set; }
        public TimeSpan? mealOut { get; set; }
        public TimeSpan? mealIn { get; set; }
        public TimeSpan? punchOut { get; set; }
        public double? totalHours { get; set; }
    }
}
