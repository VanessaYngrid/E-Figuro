﻿namespace E_Figuro_API.Models
{
    public class TimeSheet
    {
        public string time_id { get; set; }
        public string? emp_id { get; set; }     //added ? to allow to be nullable
        public string? admin_id { get; set; }
        public DateTime clock_date { get; set; }
        public TimeSpan? punchIn { get; set; }
        public TimeSpan? mealOut { get; set; }
        public TimeSpan? mealIn { get; set; }
        public TimeSpan? punchOut { get; set; }
        public double? totalHours { get; set; }

    }
}
