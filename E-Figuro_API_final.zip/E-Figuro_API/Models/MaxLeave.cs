﻿namespace E_Figuro_API.Models
{
    public class MaxLeave
    {
        public int reason_id { get; set; }
        public string leave_reason { get; set; }
        public int max_days { get; set; }

    }
}
