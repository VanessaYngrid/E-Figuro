﻿using Microsoft.Extensions.Configuration.UserSecrets;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace E_Figuro_API.Models
{
    public class DBApplication
    {
        // - Begin methods for MainWindow login
        public Response AdminLogin(SqlConnection con, ArrayList login)
        {
            Response response = new Response();

            string email = login[0].ToString();
            string attempt_password = login[1].ToString();

            string query = "select * from Administrator where admin_email='" + email + "'";

            SqlDataAdapter adapter = new SqlDataAdapter(query, con);
            DataTable dt = new DataTable();
            adapter.Fill(dt);

            if (dt.Rows.Count > 0)
            {
                string database_id = (string)dt.Rows[0]["admin_id"];
                string database_password = (string)dt.Rows[0]["admin_password"];

                if (attempt_password.CompareTo(database_password) == 0)
                {
                    login.Add(database_id);

                    response.status_code = 200;
                    response.status_message = "Administrator user login successful";
                    response.login = login;
                }
                else
                {
                    response.status_code = 100;
                    response.status_message = "Login unsuccessful, please recheck input";
                    response.login = null;
                }
            }
            else
            {
                response.status_code = 100;
                response.status_message = "Query not successful, please recheck";
                response.login = null;
            }

            return response;
        }

        public Response EmpLogin(SqlConnection con, ArrayList login)
        {
            Response response = new Response();

            string email = login[0].ToString();
            string attempt_password = login[1].ToString();

            string query = "select * from Employee where emp_email='" + email + "'";

            SqlDataAdapter adapter = new SqlDataAdapter(query, con);
            DataTable dt = new DataTable();
            adapter.Fill(dt);

            if (dt.Rows.Count > 0)
            {
                string database_id = (string)dt.Rows[0]["emp_id"];
                string database_password = (string)dt.Rows[0]["emp_password"];

                if (attempt_password.CompareTo(database_password) == 0)
                {
                    login.Add(database_id);

                    response.status_code = 200;
                    response.status_message = "Employee user login successful";
                    response.login = login;
                }
                else
                {
                    response.status_code = 100;
                    response.status_message = "Login unsuccessful, please recheck input";
                    response.login = null;
                }
            }
            else
            {
                response.status_code = 100;
                response.status_message = "Query not successful, please recheck";
                response.login = null;
            }

            return response;
        }
        // - End methods for MainWindow login

        // ---------------------------------------------------------------------------------------------------------- //

        // - Begin methods Administrator table
        public Response GetAdminUserByID(SqlConnection con, string id)
        {
            Response response = new Response();

            string query = "select * from Administrator where admin_id = '" + id + "'";

            SqlDataAdapter adapter = new SqlDataAdapter(query, con);
            DataTable dt = new DataTable();
            adapter.Fill(dt);

            if (dt.Rows.Count > 0)
            {
                Administrator user = new Administrator();
                user.admin_id = (string)dt.Rows[0]["admin_id"];
                user.admin_name = (string)dt.Rows[0]["admin_name"];
                user.admin_email = (string)dt.Rows[0]["admin_email"];
                user.admin_password = (string)dt.Rows[0]["admin_password"];
                user.admin_position = (string)dt.Rows[0]["admin_position"];
                user.admin_department = (string)dt.Rows[0]["admin_department"];
                user.admin_hire_date = (DateTime)dt.Rows[0]["admin_hire_date"];
                user.admin_salary = (double)dt.Rows[0]["admin_salary"];
                user.admin_birth_date = (DateTime)dt.Rows[0]["admin_birth_date"];
                user.admin_address = (string)dt.Rows[0]["admin_address"];

                response.status_code = 200;
                response.status_message = "Success, administrator user found";
                response.admin_user = user;
            }
            else
            {
                response.status_code = 100;
                response.status_message = "Query not successful, please recheck";
                response.admin_user = null;
            }

            return response;
        }

        public Response CreateAdminUser(SqlConnection con, Administrator user)
        {
            Response response = new Response();

            string query2 = "insert into Administrator values(@ID, @name, @email, @password, @position, @department, @hiredate, @salary, @birthdate, @address)";

            SqlCommand cmd = new SqlCommand(query2, con);
            cmd.Parameters.AddWithValue("ID", user.admin_id);
            cmd.Parameters.AddWithValue("name", user.admin_name);
            cmd.Parameters.AddWithValue("email", user.admin_email);
            cmd.Parameters.AddWithValue("password", user.admin_password);
            cmd.Parameters.AddWithValue("position", user.admin_position);
            cmd.Parameters.AddWithValue("department", user.admin_department);
            cmd.Parameters.AddWithValue("hiredate", user.admin_hire_date);
            cmd.Parameters.AddWithValue("salary", user.admin_salary);
            cmd.Parameters.AddWithValue("birthdate", user.admin_birth_date);
            cmd.Parameters.AddWithValue("address", user.admin_address);

            con.Open();
            try
            {
                int i = cmd.ExecuteNonQuery();

                if (i == 1)
                {
                    response.status_code = 200;
                    response.status_message = "Success, administrator user created";
                    response.admin_user = user;
                }
                else
                {
                    response.status_code = 100;
                    response.status_message = "Query not successful, please recheck";
                    response.admin_user = null;
                }
            }
            catch (SqlException ex)
            {
                response.status_code = 409;
                response.status_message = "Error, duplicate record detected";
                response.admin_user = user;
            }

            con.Close();
            return response;
        }

        public Response UpdateAdminUser(SqlConnection con, Administrator user, string id)
        {
            Response response = new Response();

            string query = "Update Administrator set admin_name=@name, admin_email=@email, admin_password=@password, " +
                        "admin_position=@position, admin_department=@department, admin_hire_date=@hireDate, admin_salary=@salary, " +
                        "admin_birth_date=@birthDate, admin_address=@address where admin_id='" + id + "'";

            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("ID", user.admin_id);
            cmd.Parameters.AddWithValue("name", user.admin_name);
            cmd.Parameters.AddWithValue("email", user.admin_email);
            cmd.Parameters.AddWithValue("password", user.admin_password);
            cmd.Parameters.AddWithValue("position", user.admin_position);
            cmd.Parameters.AddWithValue("department", user.admin_department);
            cmd.Parameters.AddWithValue("hiredate", user.admin_hire_date);
            cmd.Parameters.AddWithValue("salary", user.admin_salary);
            cmd.Parameters.AddWithValue("birthdate", user.admin_birth_date);
            cmd.Parameters.AddWithValue("address", user.admin_address);

            con.Open();
            int i = cmd.ExecuteNonQuery();

            if (i == 1)
            {
                response.status_code = 200;
                response.status_message = "Success, administrator user updated";
                response.admin_user = user;
            }
            else
            {
                response.status_code = 100;
                response.status_message = "Query not successful, please recheck";
                response.admin_user = null;
            }

            con.Close();
            return response;

        }

        public Response DeleteAdminUser(SqlConnection con, string id)
        {
            Response response = new Response();

            string query = "delete from Administrator where admin_id='" + id + "'";

            SqlCommand cmd = new SqlCommand(query, con);

            con.Open();
            int i = cmd.ExecuteNonQuery();

            if (i == 1)
            {
                response.status_code = 200;
                response.status_message = "Success, administrator user deleted";
            }
            else
            {
                response.status_code = 100;
                response.status_message = "Query not successful, please recheck";
            }

            con.Close();
            return response;

        }
        // - End methods Administrator table

        // ---------------------------------------------------------------------------------------------------------- //

        // - Begin methods Employee table
        public Response GetEmpUserByID(SqlConnection con, string id)
        {
            Response response = new Response();

            string query = "select * from Employee where emp_id = '" + id + "'";

            SqlDataAdapter adapter = new SqlDataAdapter(query, con);
            DataTable dt = new DataTable();
            adapter.Fill(dt);

            if (dt.Rows.Count > 0)
            {
                Employee user = new Employee();
                user.emp_id = (string)dt.Rows[0]["emp_id"];
                user.emp_name = (string)dt.Rows[0]["emp_name"];
                user.emp_email = (string)dt.Rows[0]["emp_email"];
                user.emp_password = (string)dt.Rows[0]["emp_password"];
                user.emp_position = (string)dt.Rows[0]["emp_position"];
                user.emp_department = (string)dt.Rows[0]["emp_department"];
                user.emp_hire_date = (DateTime)dt.Rows[0]["emp_hire_date"];
                user.emp_salary = (double)dt.Rows[0]["emp_salary"];
                user.emp_birth_date = (DateTime)dt.Rows[0]["emp_birth_date"];
                user.emp_address = (string)dt.Rows[0]["emp_address"];

                response.status_code = 200;
                response.status_message = "Success, employee user found";
                response.emp_user = user;
            }
            else
            {
                response.status_code = 100;
                response.status_message = "Query not successful, please recheck";
                response.emp_user = null;
            }

            return response;
        }

        public Response CreateEmpUser(SqlConnection con, Employee user)
        {
            Response response = new Response();

            string query = "insert into Employee values(@ID, @name, @email, @password, @position, @department, @hiredate, @salary, @birthdate, @address)";

            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("ID", user.emp_id);
            cmd.Parameters.AddWithValue("name", user.emp_name);
            cmd.Parameters.AddWithValue("email", user.emp_email);
            cmd.Parameters.AddWithValue("password", user.emp_password);
            cmd.Parameters.AddWithValue("position", user.emp_position);
            cmd.Parameters.AddWithValue("department", user.emp_department);
            cmd.Parameters.AddWithValue("hiredate", user.emp_hire_date);
            cmd.Parameters.AddWithValue("salary", user.emp_salary);
            cmd.Parameters.AddWithValue("birthdate", user.emp_birth_date);
            cmd.Parameters.AddWithValue("address", user.emp_address);

            con.Open();
            try
            {
                int i = cmd.ExecuteNonQuery();

                if (i == 1)
                {
                    response.status_code = 200;
                    response.status_message = "Success, employee user created";
                    response.emp_user = user;
                }
                else
                {
                    response.status_code = 100;
                    response.status_message = "Query not successful, please recheck";
                    response.emp_user = null;
                }
            }
            catch (SqlException ex)
            {
                response.status_code = 409;
                response.status_message = "Error, duplicate record detected";
                response.emp_user = null;
            }

            con.Close();
            return response;
        }

        public Response UpdateEmpUser(SqlConnection con, Employee user, string id)
        {
            Response response = new Response();

            string query = "Update Employee set emp_name=@name, emp_email=@email, emp_password=@password, " +
                        "emp_position=@position, emp_department=@department, emp_hire_date=@hireDate, emp_salary=@salary, " +
                        "emp_birth_date=@birthDate, emp_address=@address where emp_id='" + id + "'";

            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("ID", user.emp_id);
            cmd.Parameters.AddWithValue("name", user.emp_name);
            cmd.Parameters.AddWithValue("email", user.emp_email);
            cmd.Parameters.AddWithValue("password", user.emp_password);
            cmd.Parameters.AddWithValue("position", user.emp_position);
            cmd.Parameters.AddWithValue("department", user.emp_department);
            cmd.Parameters.AddWithValue("hiredate", user.emp_hire_date);
            cmd.Parameters.AddWithValue("salary", user.emp_salary);
            cmd.Parameters.AddWithValue("birthdate", user.emp_birth_date);
            cmd.Parameters.AddWithValue("address", user.emp_address);

            con.Open();
            int i = cmd.ExecuteNonQuery();

            if (i == 1)
            {
                response.status_code = 200;
                response.status_message = "Success, employee user updated";
                response.emp_user = user;
            }
            else
            {
                response.status_code = 100;
                response.status_message = "Query not successful, please recheck";
                response.emp_user = null;
            }

            con.Close();
            return response;

        }

        public Response DeleteEmpUser(SqlConnection con, string id)
        {
            Response response = new Response();

            string query = "delete from Employee where emp_id='" + id + "'";

            SqlCommand cmd = new SqlCommand(query, con);

            con.Open();
            int i = cmd.ExecuteNonQuery();

            if (i == 1)
            {
                response.status_code = 200;
                response.status_message = "Success, employee user deleted";
            }
            else
            {
                response.status_code = 100;
                response.status_message = "Query not successful, please recheck";
            }

            con.Close();
            return response;

        }
        // - End methods Employee table

        // ---------------------------------------------------------------------------------------------------------- //

        // - Begin methods TimeSheet table
        public Response GetTotalHoursByUserID(SqlConnection con, string id)
        {
            Response response = new Response();

            string query = "";

            if (id.Substring(0,1) == "A")
            {
                query = "select * from TimeSheet where admin_id = '" + id + "'";
            }
            else if (id.Substring(0,1) == "E") 
            {
                query = "select * from TimeSheet where emp_id = '" + id + "'";
            }

            SqlDataAdapter adapter = new SqlDataAdapter(query, con);
            DataTable dt = new DataTable();
            adapter.Fill(dt);

            double hours = 0, totalHours = 0;

            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    hours = Decimal.ToDouble((decimal)dt.Rows[i]["totalHours"]);
                    totalHours += hours;
                }
                response.status_code = 200;
                response.status_message = "Success, total hours calculated";
                response.totalHours = totalHours;
            }
            else
            {
                response.status_code = 100;
                response.status_message = "Query not successful, please recheck";
                response.totalHours = 0;
            }

            return response;
        }

        public Response CreateTimeSheetEntry(SqlConnection con, TimeSheet entry)
        {
            Response response = new Response();

            string query = "insert into TimeSheet values(@timeID, @empID, @adminID, @clockDate, @punchIn, @mealOut, @mealIn, @punchOut, @totalHours)";

            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("timeID", entry.time_id);

            if (entry.emp_id.Equals("null"))                                //converting "null" value to actual null value
            {
                cmd.Parameters.AddWithValue("empID", DBNull.Value);         //needs to be DBNull.Value for database
                cmd.Parameters.AddWithValue("adminID", entry.admin_id);
            }
            else if (entry.admin_id.Equals("null"))
            {
                cmd.Parameters.AddWithValue("empID", entry.emp_id);
                cmd.Parameters.AddWithValue("adminID", DBNull.Value);
            }

            cmd.Parameters.AddWithValue("clockDate", entry.clock_date);
            cmd.Parameters.AddWithValue("punchIn", entry.punchIn);

            if (entry.mealOut.Equals(TimeSpan.Zero)) 
            {
                cmd.Parameters.AddWithValue("mealOut", DBNull.Value);
            }
            else 
            {
                cmd.Parameters.AddWithValue("mealOut", entry.mealOut);
            }

            if (entry.mealIn.Equals(TimeSpan.Zero)) 
            {
                cmd.Parameters.AddWithValue("mealIn", DBNull.Value);
            }
            else 
            {
                cmd.Parameters.AddWithValue("mealIn", entry.mealIn);
            }

            if (entry.punchOut.Equals(TimeSpan.Zero))
            {
                cmd.Parameters.AddWithValue("punchOut", DBNull.Value);
            }
            else
            {
                cmd.Parameters.AddWithValue("punchOut", entry.punchOut);
            }
            
            if (entry.totalHours == 0)
            {
                cmd.Parameters.AddWithValue("totalHours", DBNull.Value);
            }
            else
            {
                cmd.Parameters.AddWithValue("totalHours", entry.totalHours);
            }

            con.Open();

            try
            {
                int i = cmd.ExecuteNonQuery();

                if (i == 1)
                {
                    response.status_code = 200;
                    response.status_message = "Success, TimeSheet entry created";
                    response.user_TimeSheet = entry;
                }
                else
                {
                    response.status_code = 100;
                    response.status_message = "Query not successful, please recheck";
                    response.user_TimeSheet = null;
                }
            }
            catch (SqlException ex)
            {
                response.status_code = 409;
                response.status_message = "Error, duplicate record detected";
                response.user_TimeSheet = null;
            }

            con.Close();
            return response;
        }

        public Response UpdateTimeSheetMealOut(SqlConnection con, ArrayList times, string id)
        {
            Response response = new Response();

            TimeSpan mealOut = TimeSpan.Parse(times[0].ToString());

            string query = "Update TimeSheet set mealOut=@mealOut where time_id='" + id + "'";

            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("mealOut", mealOut);

            con.Open();
            int i = cmd.ExecuteNonQuery();

            if (i == 1)
            {
                response.status_code = 200;
                response.status_message = "Success, TimeSheet entry updated";
                response.times = times;
            }
            else
            {
                response.status_code = 100;
                response.status_message = "Query not successful, please recheck";
                response.times = null;
            }

            con.Close();
            return response;
        }

        public Response UpdateTimeSheetMealIn(SqlConnection con, ArrayList times, string id)
        {
            Response response = new Response();

            TimeSpan mealIn = TimeSpan.Parse(times[0].ToString());

            string query = "Update TimeSheet set mealIn=@mealIn where time_id='" + id + "'";

            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("mealIn", mealIn);

            con.Open();
            int i = cmd.ExecuteNonQuery();

            if (i == 1)
            {
                response.status_code = 200;
                response.status_message = "Success, TimeSheet entry updated";
                response.times = times;
            }
            else
            {
                response.status_code = 100;
                response.status_message = "Query not successful, please recheck";
                response.times = null;
            }

            con.Close();
            return response;
        }

        public Response UpdateTimeSheetPunchOut(SqlConnection con, ArrayList times, string id)
        {
            Response response = new Response();

            TimeSpan punchIn = new TimeSpan();
            TimeSpan mealOut = new TimeSpan();
            TimeSpan mealIn = new TimeSpan();
            TimeSpan punchOut = TimeSpan.Parse(times[0].ToString());
           
            string query1 = "select punchIn, mealOut, mealIn from TimeSheet where time_id='" + id + "'";

            SqlDataAdapter adapter = new SqlDataAdapter(query1, con);
            DataTable dt = new DataTable();
            adapter.Fill(dt);

            TimeSheet dbEntry = new TimeSheet();

            if (dt.Rows.Count > 0)
            {
                punchIn = (TimeSpan)dt.Rows[0]["punchIn"];
                mealOut = (TimeSpan)dt.Rows[0]["mealOut"];
                mealIn = (TimeSpan)dt.Rows[0]["mealIn"];
            }

            double difference = ((punchOut.TotalHours - mealIn.TotalHours) + (mealOut.TotalHours - punchIn.TotalHours));
            double sumHours = difference;

            string query2 = "Update TimeSheet set punchOut=@punchOut, totalHours=@totalHours where time_id='" + id + "'";

            SqlCommand cmd = new SqlCommand(query2, con);
            cmd.Parameters.AddWithValue("punchOut", punchOut);
            cmd.Parameters.AddWithValue("totalHours", sumHours);

            con.Open();
            int i = cmd.ExecuteNonQuery();

            if (i == 1)
            {
                response.status_code = 200;
                response.status_message = "Success, TimeSheet entry updated";
                response.times = times;
            }
            else
            {
                response.status_code = 100;
                response.status_message = "Query not successful, please recheck";
                response.times = null;
            }

            con.Close();
            return response;
        }

        public Response GetAllTimeSheets(SqlConnection con, string id)
        {
            Response response = new Response();
            string query = "";

            if (id.Substring(0,1) == "A")
            {
                query = "select clock_date, punchIn, mealOut, mealIn, punchOut, totalHours from TimeSheet where admin_id='" + id + "'";
            }
            else if (id.Substring(0, 1) == "E")
            {
                query = "select clock_date, punchIn, mealOut, mealIn, punchOut, totalHours from TimeSheet where emp_id='" + id + "'";
            }

            SqlDataAdapter adapter = new SqlDataAdapter(query, con);
            DataTable dt = new DataTable();
            adapter.Fill(dt);

            List<TimeSheet_print> listTimeSheets = new List<TimeSheet_print>();

            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    TimeSheet_print timeSheet = new TimeSheet_print();

                    timeSheet.clock_date = (DateTime)dt.Rows[i]["clock_date"];
                    if (dt.Rows[i]["punchIn"] == DBNull.Value)
                    {
                        timeSheet.punchIn = TimeSpan.Zero;
                    }
                    else
                    {
                        timeSheet.punchIn = (TimeSpan)dt.Rows[i]["punchIn"];
                    }
                    if (dt.Rows[i]["mealOut"] == DBNull.Value)
                    {
                        timeSheet.mealOut = TimeSpan.Zero;
                    }
                    else
                    {
                        timeSheet.mealOut = (TimeSpan)dt.Rows[i]["mealOut"];
                    }
                    if (dt.Rows[i]["mealIn"] == DBNull.Value)
                    {
                        timeSheet.mealIn = TimeSpan.Zero;
                    }
                    else
                    {
                        timeSheet.mealIn = (TimeSpan)dt.Rows[i]["mealIn"];
                    }
                    if (dt.Rows[i]["punchOut"] == DBNull.Value)
                    {
                        timeSheet.punchOut = TimeSpan.Zero;
                    }
                    else
                    {
                        timeSheet.punchOut = (TimeSpan)dt.Rows[i]["punchOut"];
                    }
                    if (dt.Rows[i]["totalHours"] == DBNull.Value)
                    {
                        timeSheet.totalHours = 0;
                    }
                    else
                    {
                        timeSheet.totalHours = Decimal.ToDouble((decimal)dt.Rows[i]["totalHours"]);
                    }

                    listTimeSheets.Add(timeSheet);
                }
            }

            if (listTimeSheets.Count > 0)
            {
                response.status_code = 200;
                response.status_message = "Successful, here are all the products";
                response.user_TimeSheet = null;
                response.listTimeSheets = listTimeSheets;
            }
            else
            {
                response.status_code = 100;
                response.status_message = "Query not success, please recheck";
                response.user_TimeSheet= null;
                response.listTimeSheets = null;
            }

            return response;
        }

        public Response GetTimeSheetsByDate(SqlConnection con, string id, DateTime startDate, DateTime endDate)
        {
            Response response = new Response();
            string query = "";

            if (id.Substring(0, 1) == "A")
            {
                query = "select clock_date, punchIn, mealOut, mealIn, punchOut, totalHours from TimeSheet where admin_id='" + id + "'" +
                        " and clock_date>='" + startDate + "' and clock_date<='" + endDate + "'";
            }
            else if (id.Substring(0, 1) == "E")
            {
                query = "select clock_date, punchIn, mealOut, mealIn, punchOut, totalHours from TimeSheet where emp_id='" + id + "'" +
                        " and clock_date>='" + startDate + "' and clock_date<='" + endDate + "'";
            }

            SqlDataAdapter adapter = new SqlDataAdapter(query, con);
            DataTable dt = new DataTable();
            adapter.Fill(dt);

            List<TimeSheet_print> listTimeSheets = new List<TimeSheet_print>();

            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    TimeSheet_print timeSheet = new TimeSheet_print();

                    timeSheet.clock_date = (DateTime)dt.Rows[i]["clock_date"];
                    if (dt.Rows[i]["punchIn"] == DBNull.Value)
                    {
                        timeSheet.punchIn = TimeSpan.Zero;
                    }
                    else
                    {
                        timeSheet.punchIn = (TimeSpan)dt.Rows[i]["punchIn"];
                    }
                    if (dt.Rows[i]["mealOut"] == DBNull.Value)
                    {
                        timeSheet.mealOut = TimeSpan.Zero;
                    }
                    else
                    {
                        timeSheet.mealOut = (TimeSpan)dt.Rows[i]["mealOut"];
                    }
                    if (dt.Rows[i]["mealIn"] == DBNull.Value)
                    {
                        timeSheet.mealIn = TimeSpan.Zero;
                    }
                    else
                    {
                        timeSheet.mealIn = (TimeSpan)dt.Rows[i]["mealIn"];
                    }
                    if (dt.Rows[i]["punchOut"] == DBNull.Value)
                    {
                        timeSheet.punchOut = TimeSpan.Zero;
                    }
                    else
                    {
                        timeSheet.punchOut = (TimeSpan)dt.Rows[i]["punchOut"];
                    }
                    if (dt.Rows[i]["totalHours"] == DBNull.Value)
                    {
                        timeSheet.totalHours = 0;
                    }
                    else
                    {
                        timeSheet.totalHours = Decimal.ToDouble((decimal)dt.Rows[i]["totalHours"]);
                    }

                    listTimeSheets.Add(timeSheet);
                }
            }

            if (listTimeSheets.Count > 0)
            {
                response.status_code = 200;
                response.status_message = "Successful, here are all the products";
                response.user_TimeSheet = null;
                response.listTimeSheets = listTimeSheets;
            }
            else
            {
                response.status_code = 100;
                response.status_message = "Query not success, please recheck";
                response.user_TimeSheet = null;
                response.listTimeSheets = null;
            }

            return response;
        }
        // - End methods TimeSheet table

        // ---------------------------------------------------------------------------------------------------------- //

        // - Begin methods Leave/MaxLeave table
        public Response GetAllLeaveByID(SqlConnection con, string id, string leaveChoice)
        {
            Response response = new Response();

            int reason_id = 0;

            if (leaveChoice.Equals("holiday"))
            {
                reason_id = 1;
            }
            else if (leaveChoice.Equals("sick"))
            {
                reason_id = 2;
            }

            string query1 = "select max_days from MaxLeave where reason_id = '" + reason_id + "'";

            SqlDataAdapter adapter1 = new SqlDataAdapter(query1, con);
            DataTable dt1 = new DataTable();
            adapter1.Fill(dt1);

            int maxDays = 0;

            if (dt1.Rows.Count > 0)
            {
                maxDays = (int)dt1.Rows[0]["max_days"];
            }

            string query2 = "";

            if (id.Substring(0,1) == "A")
            {
                query2 = "select * from Leave where admin_id = '" + id + "' and reason_id = '" + reason_id + "'";
            }
            else if (id.Substring(0,1) == "E")
            {
                query2 = "select * from Leave where emp_id = '" + id + "' and reason_id = '" + reason_id + "'";
            }

            SqlDataAdapter adapter2 = new SqlDataAdapter(query2, con);
            DataTable dt2 = new DataTable();
            adapter2.Fill(dt2);

            int totalDaysTaken = 0;
            int daysRemaining;

            if (dt2.Rows.Count > 0)
            {
                for (int i = 0; i < dt2.Rows.Count; i++)
                {
                    Leave request = new Leave();

                    request.leave_id = (string)dt2.Rows[i]["leave_id"];
                    if (dt2.Rows[i]["emp_id"] == DBNull.Value)
                    {
                        request.emp_id = null;
                        request.admin_id = (string)dt2.Rows[i]["admin_id"];
                    }
                    else if (dt2.Rows[i]["admin_id"] == DBNull.Value)
                    {
                        request.emp_id = (string)dt2.Rows[i]["emp_id"];
                        request.admin_id = null;
                    }
                    request.reason_id = (int)dt2.Rows[i]["reason_id"];
                    request.start_date = (DateTime)dt2.Rows[i]["start_date"];
                    request.end_date = (DateTime)dt2.Rows[i]["end_date"];
                    request.no_days = (int)dt2.Rows[i]["no_days"];

                    totalDaysTaken += request.no_days;
                }

                daysRemaining = maxDays - totalDaysTaken;

                response.status_code = 200;
                response.status_message = "Query successful";
                response.days_remaining = daysRemaining;
            }
            else
            {
                response.status_code = 100;
                response.status_message = "Query not successful, please recheck";
                response.days_remaining = -1;
            }

            return response;
        }

        public Response CreateLeaveRequest(SqlConnection con, Leave request)
        {
            Response response = new Response();

            string query = "insert into Leave values(@leaveID, @empID, @adminID, @reasonID, @startDate, @endDate, @noDays)";

            SqlCommand cmd = new SqlCommand(query, con);

            // Add check to see if there are enough days remaining to submit the leave request
            // otherwise deny the request and send a message back to WPF for the user

            cmd.Parameters.AddWithValue("leaveID", request.leave_id);
            if (request.emp_id.Equals("null"))                                
            {
                cmd.Parameters.AddWithValue("empID", DBNull.Value);         
                cmd.Parameters.AddWithValue("adminID", request.admin_id);
            }
            else if (request.admin_id.Equals("null"))
            {
                cmd.Parameters.AddWithValue("empID", request.emp_id);
                cmd.Parameters.AddWithValue("adminID", DBNull.Value);
            }
            cmd.Parameters.AddWithValue("reasonID", request.reason_id);
            cmd.Parameters.AddWithValue("startDate", request.start_date);
            cmd.Parameters.AddWithValue("endDate", request.end_date);
            cmd.Parameters.AddWithValue("noDays", request.no_days);

            con.Open();

            try
            {
                int i = cmd.ExecuteNonQuery();

                if (i == 1)
                {
                    response.status_code = 200;
                    response.status_message = "Success, leave request submitted";
                    response.leave_request = request;
                }
                else
                {
                    response.status_code = 100;
                    response.status_message = "Query not successful, please recheck";
                    response.leave_request = null;
                }
            }
            catch (SqlException ex)
            {
                response.status_code = 409;
                response.status_message = "Error, duplicate record detected";
                response.leave_request = null;
            }

            con.Close();
            return response;
        }
        // - End methods Leave/MaxLeave table

    }
}
