﻿using E_Figuro_API.Models;
using Microsoft.AspNetCore.Mvc;
using System.Collections;
using System.Data.SqlClient;

namespace E_Figuro_API.Controllers
{
    [Route("[controller]")]
    [ApiController]

    public class EFiguroController : ControllerBase
    {
        private readonly IConfiguration _configuration;

        public EFiguroController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        // - Begin methods for MainWindow login
        [HttpPost]
        [Route("AdminLogin")]
        public Response AdminLogin(ArrayList login)
        {
            Response response = new Response();

            SqlConnection con = new SqlConnection(_configuration.GetConnectionString("databaseConnection"));

            DBApplication dba = new DBApplication();
            response = dba.AdminLogin(con, login);

            return response;
        }

        [HttpPost]
        [Route("EmpLogin")]
        public Response EmpLogin(ArrayList login)
        {
            Response response = new Response();

            SqlConnection con = new SqlConnection(_configuration.GetConnectionString("databaseConnection"));

            DBApplication dba = new DBApplication();
            response = dba.EmpLogin(con, login);

            return response;
        }
        // - End methods for MainWindow login

        // ---------------------------------------------------------------------------------------------------------- //

        // - Begin methods Administrator table
        [HttpGet]
        [Route("GetAdminUserByID/{id}")]
        public Response GetAdminUserByID(string id)
        {
            Response response = new Response();

            SqlConnection con = new SqlConnection(_configuration.GetConnectionString("databaseConnection"));

            DBApplication dba = new DBApplication();
            response = dba.GetAdminUserByID(con, id);

            return response;
        }

        [HttpPost]
        [Route("CreateAdminUser")]
        public Response CreateAdminUser(Administrator user)
        {
            Response response = new Response();

            SqlConnection con = new SqlConnection(_configuration.GetConnectionString("databaseConnection"));

            DBApplication dba = new DBApplication();
            response = dba.CreateAdminUser(con, user);

            return response;
        }

        [HttpPut]
        [Route("UpdateAdminUser/{id}")]
        public Response UpdateAdminUser(Administrator user, string id)
        {
            Response response = new Response();

            SqlConnection con = new SqlConnection(_configuration.GetConnectionString("databaseConnection"));

            DBApplication dba = new DBApplication();
            response = dba.UpdateAdminUser(con, user, id);

            return response;
        }

        [HttpDelete]
        [Route("DeleteAdminUser/{id}")]
        public Response DeleteAdminUser(string id)
        {
            Response response = new Response();

            SqlConnection con = new SqlConnection(_configuration.GetConnectionString("databaseConnection"));

            DBApplication dba = new DBApplication();
            response = dba.DeleteAdminUser(con, id);

            return response;
        }
        // - End methods Administrator table

        // ---------------------------------------------------------------------------------------------------------- //

        // - Begin methods Employee table
        [HttpGet]
        [Route("GetEmpUserByID/{id}")]
        public Response GetEmpUserByID(string id)
        {
            Response response = new Response();

            SqlConnection con = new SqlConnection(_configuration.GetConnectionString("databaseConnection"));

            DBApplication dba = new DBApplication();
            response = dba.GetEmpUserByID(con, id);

            return response;
        }

        [HttpPost]
        [Route("CreateEmpUser")]
        public Response CreateEmpUser(Employee user)
        {
            Response response = new Response();

            SqlConnection con = new SqlConnection(_configuration.GetConnectionString("databaseConnection"));

            DBApplication dba = new DBApplication();
            response = dba.CreateEmpUser(con, user);

            return response;
        }

        [HttpPut]
        [Route("UpdateEmpUser/{id}")]
        public Response UpdateEmpUser(Employee user, string id)
        {
            Response response = new Response();

            SqlConnection con = new SqlConnection(_configuration.GetConnectionString("databaseConnection"));

            DBApplication dba = new DBApplication();
            response = dba.UpdateEmpUser(con, user, id);

            return response;
        }

        [HttpDelete]
        [Route("DeleteEmpUser/{id}")]
        public Response DeleteEmpUser(string id)
        {
            Response response = new Response();

            SqlConnection con = new SqlConnection(_configuration.GetConnectionString("databaseConnection"));

            DBApplication dba = new DBApplication();
            response = dba.DeleteEmpUser(con, id);

            return response;
        }
        // - End methods Employee table

        // ---------------------------------------------------------------------------------------------------------- //

        // - Begin methods TimeSheet table
        [HttpGet]
        [Route("GetTotalHoursByUserID/{id}")]
        public Response GetTotalHoursByUserID(string id)
        {
            Response response = new Response();

            SqlConnection con = new SqlConnection(_configuration.GetConnectionString("databaseConnection"));

            DBApplication dba = new DBApplication();
            response = dba.GetTotalHoursByUserID(con, id);

            return response;
        }

        [HttpPost]
        [Route("CreateTimeSheetEntry")]
        public Response CreateTimeSheetEntry(TimeSheet entry)
        {
            Response response = new Response();

            SqlConnection con = new SqlConnection(_configuration.GetConnectionString("databaseConnection"));

            DBApplication dba = new DBApplication();
            response = dba.CreateTimeSheetEntry(con, entry);

            return response;
        }

        [HttpPut]
        [Route("UpdateTimeSheetMealOut/{id}")]
        public Response UpdateTimeSheetMealOut(ArrayList times, string id)
        {
            Response response = new Response();

            SqlConnection con = new SqlConnection(_configuration.GetConnectionString("databaseConnection"));

            DBApplication dba = new DBApplication();
            response = dba.UpdateTimeSheetMealOut(con, times, id);

            return response;
        }

        [HttpPut]
        [Route("UpdateTimeSheetMealIn/{id}")]
        public Response UpdateTimeSheetMealIn(ArrayList times, string id)
        {
            Response response = new Response();

            SqlConnection con = new SqlConnection(_configuration.GetConnectionString("databaseConnection"));

            DBApplication dba = new DBApplication();
            response = dba.UpdateTimeSheetMealIn(con, times, id);

            return response;
        }

        [HttpPut]
        [Route("UpdateTimeSheetPunchOut/{id}")]
        public Response UpdateTimeSheetPunchOut(ArrayList times, string id)
        {
            Response response = new Response();

            SqlConnection con = new SqlConnection(_configuration.GetConnectionString("databaseConnection"));

            DBApplication dba = new DBApplication();
            response = dba.UpdateTimeSheetPunchOut(con, times, id);

            return response;
        }

        [HttpGet]
        [Route("GetAllTimeSheets/{id}")]
        public Response GetAllTimeSheets(string id)
        {
            Response response = new Response();

            SqlConnection con = new SqlConnection(_configuration.GetConnectionString("databaseConnection"));

            DBApplication dba = new DBApplication();
            response = dba.GetAllTimeSheets(con, id);

            return response;
        }

        [HttpGet]
        [Route("GetTimeSheetsByDate")]
        public Response GetTimeSheetsByDate(string userID, DateTime startDate, DateTime endDate)
        {
            //userID, startDate, endDate are sent to restAPI through GET request in the form of the URL (see E-Figuro_WPF - TimeSheet)
            Response response = new Response();

            SqlConnection con = new SqlConnection(_configuration.GetConnectionString("databaseConnection"));

            DBApplication dba = new DBApplication();
            response = dba.GetTimeSheetsByDate(con, userID, startDate, endDate);

            return response;
        }
        // - End methods TimeSheet table

        // ---------------------------------------------------------------------------------------------------------- //

        // - Begin methods Leave/MaxLeave table
        [HttpGet]
        [Route("GetAllLeaveByID")]
        public Response GetAllLeaveByID(string userID, string leaveChoice)
        {
            Response response = new Response();

            SqlConnection con = new SqlConnection(_configuration.GetConnectionString("databaseConnection"));

            DBApplication dba = new DBApplication();
            response = dba.GetAllLeaveByID(con, userID, leaveChoice);

            return response;
        }

        [HttpPost]
        [Route("CreateLeaveRequest")]
        public Response CreateLeaveRequest(Leave request)
        {
            Response response = new Response();

            SqlConnection con = new SqlConnection(_configuration.GetConnectionString("databaseConnection"));

            DBApplication dba = new DBApplication();
            response = dba.CreateLeaveRequest(con, request);

            return response;
        }
        // - End methods Leave/MaxLeave table

    }
}
